
# REST API for PHP

A simple HTTP based RESTful API library will enable your apps to send text messages and make phone calls through [Unifonic Cloud Communication Platform] (http://www.unifonic.com)

* [Installation](https://github.com/Unifonic/SMS-Voice-PHPSDK/wiki/How-to-use-the-SDK)
* [Rest API Documentation](http://docs.unifonic.apiary.io/)
