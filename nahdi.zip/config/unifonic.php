<?php

return [
    'sender_name' => 'Nahdi',
    'result_url' => 'https://nahdi.com/result/',
    'sid' => ['Your Rest AppSid'],
    'url' => 'http://api.unifonic.com/rest/',
];
