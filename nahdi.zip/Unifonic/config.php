<?php


    return array(
        'AppSid' => ['Your Rest AppSid'],
        'ApiURL' => 'http://api.unifonic.com/rest/',
    );
